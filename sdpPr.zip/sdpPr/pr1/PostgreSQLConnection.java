public class PostgreSQLConnection implements DatabaseConnection {

    @Override
    public void connect() {
        System.out.println("Connected to PostgreSQL Database.");
    }

    @Override
    public void disconnect() {
        System.out.println("Disconnected from PostgreSQL Database.");
    }

    @Override
    public void query() {
        System.out.println("Executing query: SELECT * FROM orders.");
    }
}
