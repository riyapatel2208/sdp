import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter database type (mysql, postgresql, mongodb): ");
        String dbType = scanner.nextLine();

        DatabaseConnection connection = null;

        try {
            connection = DatabaseFactory.getDatabaseConnection(dbType);
            connection.connect();
            connection.query(); // Perform a database-specific query
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        scanner.close();
    }
}
