public class MongoDBConnection implements DatabaseConnection {

    @Override
    public void connect() {
        System.out.println("Connected to MongoDB Database.");
    }

    @Override
    public void disconnect() {
        System.out.println("Disconnected from MongoDB Database.");
    }

    @Override
    public void query() {
        System.out.println("Executing query: db.collection.find({}).");
    }
}
