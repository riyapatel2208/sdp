public interface DatabaseConnection {
    void connect();
    void disconnect();
    void query(); // Add this method to handle specific queries
}
