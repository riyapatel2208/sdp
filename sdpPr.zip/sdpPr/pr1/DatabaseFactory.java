public class DatabaseFactory {

    public static DatabaseConnection getDatabaseConnection(String dbType) {
        if (dbType == null) {
            return null;
        }
        switch (dbType.toLowerCase()) {
            case "mysql":
                return new MySQLConnection();
            case "postgresql":
                return new PostgreSQLConnection();
            case "mongodb":
                return new MongoDBConnection();
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }
}
