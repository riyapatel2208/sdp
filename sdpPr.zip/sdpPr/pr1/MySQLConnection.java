public class MySQLConnection implements DatabaseConnection {

    @Override
    public void connect() {
        System.out.println("Connected to MySQL Database.");
    }

    @Override
    public void disconnect() {
        System.out.println("Disconnected from MySQL Database.");
    }

    @Override
    public void query() {
        System.out.println("Executing query: SELECT * FROM users.");
    }
}
