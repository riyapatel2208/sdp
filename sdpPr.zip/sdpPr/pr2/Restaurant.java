public class Restaurant {
    public static void main(String[] args) {
        FoodOrderSystem.startOrdering();
    }
}
