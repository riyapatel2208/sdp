public class GulabJamun implements Dessert {
    @Override
    public void prepare() {
        System.out.println("Preparing Gulab Jamun - An Indian Dessert");
    }
}
