public interface Appetizer {
    void prepare();
}
