import java.util.Scanner;

public class FoodOrderSystem {
    private CuisineFactory cuisineFactory;

    public FoodOrderSystem(CuisineFactory cuisineFactory) {
        this.cuisineFactory = cuisineFactory;
    }

    // Function to let user select the meal type
    public void placeOrder(int choice) {
        switch (choice) {
            case 1:
                cuisineFactory.createAppetizer().prepare();
                break;
            case 2:
                cuisineFactory.createMainCourse().prepare();
                break;
            case 3:
                cuisineFactory.createDessert().prepare();
                break;
            case 4:
                cuisineFactory.createAppetizer().prepare();
                cuisineFactory.createMainCourse().prepare();
                cuisineFactory.createDessert().prepare();
                break;
            default:
                System.out.println("Invalid choice! Please try again.");
        }
    }

    // Method to handle user input
    public static void startOrdering() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to our Multi-Cuisine Restaurant!");
        System.out.println("Choose your cuisine:\n1. Indian\n2. Chinese");
        int cuisineChoice = scanner.nextInt();

        CuisineFactory factory;
        if (cuisineChoice == 1) {
            factory = new IndianCuisineFactory();
        } else if (cuisineChoice == 2) {
            factory = new ChineseCuisineFactory();
        } else {
            System.out.println("Invalid selection. Exiting...");
            scanner.close();
            return;
        }

        FoodOrderSystem orderSystem = new FoodOrderSystem(factory);

        System.out.println("Choose your meal type:\n1. Appetizer\n2. Main Course\n3. Dessert\n4. Full Course Meal");
        int mealChoice = scanner.nextInt();
        
        orderSystem.placeOrder(mealChoice);

        System.out.println("Thank you for ordering! Enjoy your meal. 😊");
        scanner.close();
    }
}
