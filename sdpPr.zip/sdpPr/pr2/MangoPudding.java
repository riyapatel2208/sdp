public class MangoPudding implements Dessert {
    @Override
    public void prepare() {
        System.out.println("Preparing Mango Pudding - A Chinese Dessert");
    }
}
