public class Samosa implements Appetizer {
    @Override
    public void prepare() {
        System.out.println("Preparing Samosa - An Indian Appetizer");
    }
}
