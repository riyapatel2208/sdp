public class SpringRolls implements Appetizer {
    @Override
    public void prepare() {
        System.out.println("Preparing Spring Rolls - A Chinese Appetizer");
    }
}
