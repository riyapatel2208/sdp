public class FriedRice implements MainCourse {
    @Override
    public void prepare() {
        System.out.println("Preparing Fried Rice - A Chinese Main Course");
    }
}
