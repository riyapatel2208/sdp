public class IndianCuisineFactory implements CuisineFactory {
    @Override
    public Appetizer createAppetizer() {
        return new Samosa();
    }

    @Override
    public MainCourse createMainCourse() {
        return new Biryani();
    }

    @Override
    public Dessert createDessert() {
        return new GulabJamun();
    }
}
