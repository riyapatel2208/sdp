public class ChineseCuisineFactory implements CuisineFactory {
    @Override
    public Appetizer createAppetizer() {
        return new SpringRolls();
    }

    @Override
    public MainCourse createMainCourse() {
        return new FriedRice();
    }

    @Override
    public Dessert createDessert() {
        return new MangoPudding();
    }
}
