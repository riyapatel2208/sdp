public class Biryani implements MainCourse {
    @Override
    public void prepare() {
        System.out.println("Preparing Biryani - An Indian Main Course");
    }
}
