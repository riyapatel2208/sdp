import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter role (admin/user): ");
        String role = scanner.nextLine().trim();

        File proxyFile = new ProxyFile(role);

        while (true) {
            System.out.println("\nChoose operation:");
            System.out.println("1. Create File");
            System.out.println("2. Rename File");
            System.out.println("3. Delete File");
            System.out.println("4. Exit");

            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // clear buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter file name to create: ");
                    String createName = scanner.nextLine();
                    proxyFile.create(createName);
                    break;
                case 2:
                    System.out.print("Enter old file name: ");
                    String oldName = scanner.nextLine();
                    System.out.print("Enter new file name: ");
                    String newName = scanner.nextLine();
                    proxyFile.rename(oldName, newName);
                    break;
                case 3:
                    System.out.print("Enter file name to delete: ");
                    String deleteName = scanner.nextLine();
                    proxyFile.delete(deleteName);
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
