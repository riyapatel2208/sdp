public class RealFile implements File {

    @Override
    public void create(String name) {
        try {
            java.io.File file = new java.io.File(name);
            if (file.createNewFile()) {
                System.out.println("File created: " + name);
            } else {
                System.out.println("File already exists: " + name);
            }
        } catch (Exception e) {
            System.out.println("Error creating file: " + e.getMessage());
        }
    }

    @Override
    public void rename(String oldName, String newName) {
        java.io.File oldFile = new java.io.File(oldName);
        java.io.File newFile = new java.io.File(newName);
        if (oldFile.exists() && oldFile.renameTo(newFile)) {
            System.out.println("File renamed to: " + newName);
        } else {
            System.out.println("Rename failed.");
        }
    }

    @Override
    public void delete(String name) {
        java.io.File file = new java.io.File(name);
        if (file.exists() && file.delete()) {
            System.out.println("File deleted: " + name);
        } else {
            System.out.println("Delete failed.");
        }
    }
}
