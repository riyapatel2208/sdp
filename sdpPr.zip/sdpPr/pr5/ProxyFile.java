public class ProxyFile implements File {
    private boolean isAdmin;
    private boolean isUser;
    private RealFile realFile;

    public ProxyFile(String role) {
        if (role.equalsIgnoreCase("admin")) {
            this.isAdmin = true;
        } else if (role.equalsIgnoreCase("user")) {
            this.isUser = true;
        } else {
            System.out.println("Invalid role. Access denied.");
        }
        realFile = new RealFile();
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public boolean isUser() {
        return isUser;
    }

    @Override
    public void create(String name) {
        if (isAdmin || isUser) {
            realFile.create(name);
        } else {
            System.out.println("Access Denied: Unauthorized user");
        }
    }

    @Override
    public void rename(String oldName, String newName) {
        if (isAdmin) {
            realFile.rename(oldName, newName);
        } else {
            System.out.println("Access Denied: Only admin can rename files");
        }
    }

    @Override
    public void delete(String name) {
        if (isAdmin) {
            realFile.delete(name);
        } else {
            System.out.println("Access Denied: Only admin can delete files");
        }
    }
}
