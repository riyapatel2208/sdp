class Publisher {
    private List<Subscriber> subscribers = new ArrayList<>();

    public void register(Subscriber s) {
        subscribers.add(s);
        System.out.println("📢 New subscriber added!");
    }

    public void unregister(Subscriber s) {
        subscribers.remove(s);
        System.out.println("🚫 A subscriber has been removed.");
    }

    public void notifySubscribers(String news) {
        System.out.println("\n🗞️ Broadcasting news: " + news);
        for (Subscriber s : subscribers) {
            s.update(news);
            try {
                Thread.sleep(500); // Simulate broadcast delay
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("✅ All subscribers have been notified.\n");
    }
}
