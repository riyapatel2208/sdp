class SportsNews implements Subscriber {
    private String name;

    public SportsNews(String name) {
        this.name = name;
    }

    public void update(String news) {
        System.out.println("🏈 " + name + " received Sports News: " + news);
    }
}