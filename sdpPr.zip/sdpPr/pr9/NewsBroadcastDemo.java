public class NewsBroadcastDemo {
    public static void main(String[] args) {
        Publisher newsChannel = new Publisher();

        Subscriber john = SubscriberFactory.createSubscriber("sports", "John");
        Subscriber alice = SubscriberFactory.createSubscriber("music", "Alice");
        Subscriber emma = SubscriberFactory.createSubscriber("dance", "Emma");

        newsChannel.register(john);
        newsChannel.register(alice);
        newsChannel.register(emma);

        newsChannel.notifySubscribers("Breaking: Local team wins championship!");
        newsChannel.notifySubscribers("New album released by top artist!");
        newsChannel.notifySubscribers("Dance battle finals live tonight!");

        newsChannel.unregister(alice);

        newsChannel.notifySubscribers("Exclusive: Upcoming sports schedule!");
    }
}
