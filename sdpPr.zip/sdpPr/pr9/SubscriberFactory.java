class SubscriberFactory {
    public static Subscriber createSubscriber(String type, String name) {
        switch (type.toLowerCase()) {
            case "sports":
                return new SportsNews(name);
            case "music":
                return new MusicNews(name);
            case "dance":
                return new DanceNews(name);
            default:
                throw new IllegalArgumentException("❌ Unknown subscriber type: " + type);
        }
    }
}