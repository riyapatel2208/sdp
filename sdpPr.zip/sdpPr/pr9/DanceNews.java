class DanceNews implements Subscriber {
    private String name;

    public DanceNews(String name) {
        this.name = name;
    }

    public void update(String news) {
        System.out.println("💃 " + name + " received Dance News: " + news);
    }
}