class MusicNews implements Subscriber {
    private String name;

    public MusicNews(String name) {
        this.name = name;
    }

    public void update(String news) {
        System.out.println("🎵 " + name + " received Music News: " + news);
    }
}