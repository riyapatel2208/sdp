public class Viper extends Snake {
    public Viper() {
        super("Viper", new VenomousBite());
    }
}