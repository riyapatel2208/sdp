public class VenomousBite implements BiteBehavior {
    @Override
    public void bite() {
        System.out.println("This snake delivers a venomous bite!");
    }
}
