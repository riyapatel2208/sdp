public class Python extends Snake {
    public Python() {
        super("Python", new NonVenomousBite());
    }
}