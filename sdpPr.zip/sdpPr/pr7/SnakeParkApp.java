public class SnakeParkApp {
    public static void main(String[] args) {
        Snake cobra = new Cobra();
        cobra.performBite(); // venomous

        Snake python = new Python();
        python.performBite(); // non-venomous

        // Changing behavior at runtime (e.g., due to mutation or misclassification)
        python.setBiteBehavior(new VenomousBite());
        python.performBite(); // now venomous
    }
}
