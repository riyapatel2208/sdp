public class Cobra extends Snake {
    public Cobra() {
        super("Cobra", new VenomousBite());
    }
}