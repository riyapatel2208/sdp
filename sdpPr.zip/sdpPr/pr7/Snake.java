public abstract class Snake {
    protected String name;
    protected BiteBehavior biteBehavior;

    public Snake(String name, BiteBehavior biteBehavior) {
        this.name = name;
        this.biteBehavior = biteBehavior;
    }

    public void performBite() {
        biteBehavior.bite();
    }

    public void setBiteBehavior(BiteBehavior bb) {
        this.biteBehavior = bb;
    }

    public String getName() {
        return name;
    }
}
