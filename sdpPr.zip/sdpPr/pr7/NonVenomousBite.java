public class NonVenomousBite implements BiteBehavior {
    @Override
    public void bite() {
        System.out.println("This snake bites but it's non-venomous.");
    }
}