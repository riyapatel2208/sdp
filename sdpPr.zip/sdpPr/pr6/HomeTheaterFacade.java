public class HomeTheaterFacade {
    private DVDPlayer dvd;
    private Projector projector;
    private Lights lights;

    public HomeTheaterFacade(DVDPlayer dvd, Projector projector, Lights lights) {
        this.dvd = dvd;
        this.projector = projector;
        this.lights = lights;
    }

    public void handleUserInput(String input) {
        input = input.trim().toLowerCase();

        switch (input) {
            case "watch movie":
                watchMovie("Inception");
                break;
            case "movie over":
                endMovie();
                break;
            default:
                System.out.println("Invalid input. Try 'watch movie', 'movie over', or 'exit'.");
        }
    }

    private void watchMovie(String movie) {
        System.out.println("Get ready to watch a movie...");
        lights.dim(10);
        projector.on();
        projector.setMode("Cinema");
        dvd.on();
        dvd.play(movie);
    }

    private void endMovie() {
        System.out.println("Shutting movie theater down...");
        lights.on();
        projector.off();
        dvd.off();
    }
}
