public class Projector {
    public void on() {
        System.out.println("Projector is ON");
    }

    public void off() {
        System.out.println("Projector is OFF");
    }

    public void setMode(String mode) {
        System.out.println("Projector mode set to: " + mode);
    }
}
