import java.util.Scanner;

public class FacadePatternUserInput {
    public static void main(String[] args) {
        DVDPlayer dvd = new DVDPlayer();
        Projector projector = new Projector();
        Lights lights = new Lights();

        HomeTheaterFacade homeTheater = new HomeTheaterFacade(dvd, projector, lights);

        Scanner scanner = new Scanner(System.in);
        String input;

        System.out.println("Type 'watch movie' to start, 'movie over' to stop, or 'exit' to quit.");

        while (true) {
            System.out.print("User: ");
            input = scanner.nextLine();

            if (input.trim().equalsIgnoreCase("exit")) {
                System.out.println("Exiting...");
                break;
            }

            homeTheater.handleUserInput(input);
        }

        scanner.close();
    }
}
