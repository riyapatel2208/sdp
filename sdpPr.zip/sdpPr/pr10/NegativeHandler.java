class NegativeHandler implements Handler {
    private Handler next;

    public void setNext(Handler next) {
        this.next = next;
    }

    public void handle(int request) {
        if (request < 0) {
            System.out.println("NegativeHandler: " + request);
        } else if (next != null) {
            next.handle(request);
        }
    }
}
