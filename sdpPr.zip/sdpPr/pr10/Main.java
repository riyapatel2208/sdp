public class Main {
    public static void main(String[] args) {
        Handler pos = new PositiveHandler();
        Handler neg = new NegativeHandler();
        Handler zero = new ZeroHandler();

        pos.setNext(neg);
        neg.setNext(zero);

        int[] nums = {10, -5, 0, 8, -1};

        for (int num : nums) {
            pos.handle(num);
        }
    }
}
