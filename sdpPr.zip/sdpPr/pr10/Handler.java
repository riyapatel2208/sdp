interface Handler {
    void setNext(Handler next);
    void handle(int request);
}
