import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        databaseConnection db = databaseConnection.getInstance();

        while (true) {
            System.out.println("\n=== Student Management System ===");
            System.out.println("1. Connect to Database");
            System.out.println("2. Disconnect from Database");
            System.out.println("3. Exit");
            System.out.print("Choose an option (1-3): ");

            int choice = -1;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    db.getConnection();
                    break;
                case 2:
                    db.closeConnection();
                    break;
                case 3:
                    System.out.println("👋 Exiting... Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("❌ Invalid choice. Please try again.");
            }
        }
    }
}
