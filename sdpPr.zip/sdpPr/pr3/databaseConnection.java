public class databaseConnection {
    // Singleton instance
    private static databaseConnection instance;

    // Simulated "connection" status
    private boolean connection;

    // Private constructor to prevent direct instantiation
    private databaseConnection() {
        this.connection = false;
    }

    // Public method to get the singleton instance
    public static synchronized databaseConnection getInstance() {
        if (instance == null) {
            instance = new databaseConnection();
        }
        return instance;
    }

    // Simulated method to get a database connection
    public boolean getConnection() {
        if (!connection) {
            connection = true;
            System.out.println("Database connection established (Mock).");
        } else {
            System.out.println("Already connected to the database (Mock).");
        }
        return connection;
    }

    // Simulated method to close the database connection
    public void closeConnection() {
        if (connection) {
            connection = false;
            System.out.println("Database connection closed (Mock).");
        } else {
            System.out.println("No active database connection to close (Mock).");
        }
    }
}
