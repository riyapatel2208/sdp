import java.io.IOException;
import java.io.OutputStream;

public class OutputStreamDecorator extends OutputStream {
    protected OutputStream outputStream;

    public OutputStreamDecorator(OutputStream outputStream) {
        this.outputStream = outputStream;
    }

    @Override
    public void write(int b) throws IOException {
        outputStream.write(b);
    }

    @Override
    public void close() throws IOException {
        outputStream.close();
    }
}