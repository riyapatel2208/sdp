import java.io.IOException;
import java.io.InputStream;

public class CountingInputStream extends InputStreamDecorator {
    private int charCount = 0, wordCount = 0, lineCount = 0;
    private boolean inWord = false;

    public CountingInputStream(InputStream inputStream) {
        super(inputStream);
    }

    @Override
    public int read() throws IOException {
        int data = super.read();
        if (data != -1) {
            charCount++;
            
            if (Character.isWhitespace(data)) {
                inWord = false;
                if (data == '\n') {
                    lineCount++;
                }
            } else if (!inWord) {
                wordCount++;
                inWord = true;
            }
        }
        return data;
    }

    public int getCharacterCount() { return charCount; }
    public int getWordCount() { return wordCount; }
    public int getLineCount() { return lineCount; }
}
