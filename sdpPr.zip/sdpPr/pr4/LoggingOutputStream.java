import java.io.IOException;
import java.io.OutputStream;

public class LoggingOutputStream extends OutputStreamDecorator {
    public LoggingOutputStream(OutputStream outputStream) {
        super(outputStream);
    }

    @Override
    public void write(int b) throws IOException {
        System.out.println("Byte Written: " + b);
        super.write(b);
    }
}