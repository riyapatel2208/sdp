import java.io.*;

public class Main{
    public static void main(String[] args) {
        try {
            // InputStream Example
            InputStream fileInputStream = new FileInputStream("input.txt");
            InputStream loggingStream = new LoggingInputStream(fileInputStream);
            CountingInputStream countingStream = new CountingInputStream(loggingStream);

            while (countingStream.read() != -1) {}

            System.out.println("Characters: " + countingStream.getCharacterCount());
            System.out.println("Words: " + countingStream.getWordCount());
            System.out.println("Lines: " + countingStream.getLineCount());

            countingStream.close();

            // OutputStream Example
            OutputStream fileOutputStream = new FileOutputStream("output.txt");
            OutputStream loggingOutputStream = new LoggingOutputStream(fileOutputStream);

            String data = "Hello, Decorator Pattern!";
            for (char c : data.toCharArray()) {
                loggingOutputStream.write(c);
            }

            loggingOutputStream.close();
            System.out.println("Data written to output.txt");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}