import java.io.IOException;
import java.io.InputStream;

public class LoggingInputStream extends InputStreamDecorator {
    public LoggingInputStream(InputStream inputStream) {
        super(inputStream);
    }

    @Override
    public int read() throws IOException {
        int data = super.read();
        if (data != -1) {
            System.out.println("Byte Read: " + data);
        }
        return data;
    }
}