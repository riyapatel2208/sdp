public class NewsSystemTest {
    public static void main(String[] args) {
        NewsPublisher publisher = new NewsPublisher();

        Subscriber s1 = new SportsNews("Alice");
        Subscriber s2 = new MusicNews("Bob");
        Subscriber s3 = new DanceNews("Charlie");

        publisher.register(s1);
        publisher.register(s2);
        publisher.register(s3);

        publisher.notifySubscribers("Breaking news: Major event happening now!");

        publisher.unregister(s2);
        publisher.notifySubscribers("Update: New developments on the event.");
    }
}
