public interface Publisher {
    void register(Subscriber subscriber);
    void unregister(Subscriber subscriber);
    void notifySubscribers(String news);
}
