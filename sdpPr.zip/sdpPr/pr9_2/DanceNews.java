public class DanceNews implements Subscriber {
    private String name;

    public DanceNews(String name) {
        this.name = name;
    }

    @Override
    public void update(String news) {
        System.out.println(name + " received dance news: " + news);
    }
}
