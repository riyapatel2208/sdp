public class MusicNews implements Subscriber {
    private String name;

    public MusicNews(String name) {
        this.name = name;
    }

    @Override
    public void update(String news) {
        System.out.println(name + " received music news: " + news);
    }
}
